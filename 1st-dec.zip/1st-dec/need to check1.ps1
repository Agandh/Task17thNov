﻿$inputlog =Get-Content E:\Agandh\1st-dec\doc.txt

foreach ($log in $inputlog) {


if ($somesentence -match "^error")

{

Write-Host "this file contains error"


}

}