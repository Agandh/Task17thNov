﻿

New-Item -ItemType file -Path "C:\Users\Administrator\Documents\WindowsPowerShell\Microsoft.PowerShellISE_profile.ps1" -Force