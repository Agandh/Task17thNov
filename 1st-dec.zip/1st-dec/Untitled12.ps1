﻿

"aa" -match "^[a-da]$"
"aa" -match "^[a-de]$"
"ae" -match "^[a-de]$"


"e" -match "^[a-de]$"

"a" -match "^[a-dn]$"
"an" -match "^[a-dn]$"
"e" -match "^[a-dn]{2}$"
"e" -match "^[a-dn]{2}$"

"abd" -match "^[b-da]{3}$"
"abd" -match "^[b-da]{3}$"
"abda" -match "^[b-da]{3}$"
"aa" -match "^[b-da]{3,4}$"

"abd" -match "^[b-da]{3,4}$"
"abd" -match "^[b-da]{0,2}$"

"d" -match "^[b-da]{0,2}$"
"a" -match "^[b-da]{0,2}$"

"zx" -match "^[b-da]{0,2}$"

"" -match "^[b-da]{0,2}$"

"b" -match "^[^b-da]{0,2}$"

"zx" -match "^[^b-da]{0,2}$"

"a" -match "^[z-pa]{1,2}$"


"abc" -match "^[abc]{3}$"

"abcd" -match "^[abc]{3}$"

"aac" -match "^[abc]{3}$"

"abdc" -match "^[a-d]{3,5}[-]$"

"abc" -match "^[a-d]{3,5}[-]$"


"abc-" -match "^[a-d]{3,5}[-]$"

"abc-" -match "^[a-d]{3,5}[-/]$"

"abc/" -match "^[a-d]{3,5}[-/]$"

"abc." -match "^[a-d]{3,5}[-/.]$"

"abc/." -match "^[a-d]{3,5}[-/.]$"

"abc/" -match "^[a-d]{3,5}[-/.]?$"

"abc?" -match "^[a-d]{3,5}[-/.]?$"

"abc" -match "^[a-d]{3,5}[-/.]?$"

"agfs" -match "^[a-d]{3,5}[^\w?$]?$"

"abc" -match "^[^\w?$]?$"
"a" -match "^\w?$"
"z" -match "^\w?$"
"zz" -match "^\w?$"

"3" -match "^\w?$"

"3" -match "^\w$"

"34" -match "^\w$"
"d" -match "^\w$"

"" -match "^\w$"
"" -match "^\w?$"
"aa" -match "^\w\w$"
"d" -match "^\w\w$"

"d" -match "^\d\d$"
"dd" -match "^\d\d$"
"45" -match "^\d\d$"
"11" -match "^[0-9]$"
"1" -match "^[0-9]$"
"1266" -match "[0-9]$"
"a1" -match "[0-9]$"
"9z" -match "[0-9]$"

"55" -match "^[0-56]$"
"5" -match "^[0-56]$"
"23" -match "^[0-56]$"
"7" -match "^[0-56]$"
"6" -match "^[0-56]$"
"12" -match "^[0-5][12]$"
"51" -match "^[0-5][12]$"
"4" -match "^[0-5][12]$"
"44" -match "^[0-5][12]$"
"44" -match "^[0-5][12]$"
"13" -match "^[0-1][345]$"
"15" -match "^[0-1][345]$"
"16" -match "^[0-1][345]$"
"16" -match "^[0-1]?[345]$"
"" -match "^[0-1]?[345]$"
"15" -match "^[0-1]?[345]$"
"03" -match "^[0-1]?[345]$"
"11" -match "^[0-1]|[345]$"
"" -match "^[0-1]|[345]$"
"63" -match "^[0-1]|[345]$"






