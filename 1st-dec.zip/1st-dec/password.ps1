﻿$cred = Get-Credential
$username = "admin"
$password = "Pass1234$$" | ConvertTo-SecureString -AsPlainText -Force

$cread1 = New-Object -TypeName pscredential -ArgumentList $username,$password

$pass = $password | ConvertFrom-SecureString
$pass | Out-File "E:\Agandh\1st-dec\pass.txt"
$password =Get-Content "E:\Agandh\1st-dec\pass.txt" | ConvertTo-SecureString