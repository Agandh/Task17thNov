﻿$hashtable = @{


fname="satish"
lname="Kolekar"



}



New-Object pscustomobject -Property $hashtable

$object =[pscustomobject]$hashtable