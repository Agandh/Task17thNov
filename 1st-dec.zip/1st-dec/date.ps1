$date=Read-Host "provode date dd-mm-yy"

$date -match "^(0?[1-9]|[12][0-9]|3[0-1])[-](0?[1-9]|1[02])[-]\d\d$"




<#
"5" -match "^0?[1-9]$"
"20" -match "^1?[0-9]$"
"30" -match "^2[0-9]$"
"32" -match "^3[0-1]$"
#>